/***********************************************************************
 *
 *	Definitions for various path related things.  These are compiled into
 *	the GNU Smalltalk interpreter and are used for finding various files
 *	(the image file, the kernel .st files, etc.).
 *
 ***********************************************************************/


/***********************************************************************
 *
 * Copyright (C) 1990, 1991 Free Software Foundation, Inc.
 * Written by Steve Byrne.
 *
 * This file is part of GNU Smalltalk.
 *
 * GNU Smalltalk is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 1, or (at your option) any later 
 * version.
 * 
 * GNU Smalltalk is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * GNU Smalltalk; see the file COPYING.  If not, write to the Free Software
 * Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  
 *
 ***********************************************************************/



/*
 *    Change Log
 * ============================================================================
 * Author      Date       Change 
 * sbyrne    15 Oct 89	  Created.
 *
 */


/***********************************************************************
 *
 *	You'll need to change these definitions if you do not install GNU
 *	Smalltalk in the standard place (which, as defined here, is
 *	/usr/local/smalltalk).  You should save this file as mstpaths.h and
 *	leave mstpaths.h-dist in its original form.
 *
 ***********************************************************************/


#ifndef __MSTPATHS__
#define __MSTPATHS__

/* This defines where the kernel smalltalk (.st) files can be found */
#define KERNEL_PATH "/usr/local/smalltalk"

/* This defines where to search for the saved binary image */
#define IMAGE_PATH "/usr/local/smalltalk"

#endif /* __MSTPATHS__ */
