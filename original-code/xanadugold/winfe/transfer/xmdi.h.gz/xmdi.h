// ObjectWindows - (C) Copyright 1992 by Borland International

/* Anyone that makes a dialog box needs the app */
extern PTApplication TheApp;
