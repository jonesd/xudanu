#ifndef FECOLOR
#define FECOLOR

extern HFONT TheTextFont;
extern HFONT TheLinkFont;
extern HFONT TheVariantFont;
extern HFONT TheHistoryFont;

#endif // FECOLOR
