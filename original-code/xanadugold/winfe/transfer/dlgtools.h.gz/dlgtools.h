#ifndef DLGTOOLS
#define DLGTOOLS

#include <edit.h>

class DialogTools {
	
	static void setEditText(XuEditionP edition, TEditP edit);
	static void setEditText(XuSequenceP sequence, TEditP edit);
}
