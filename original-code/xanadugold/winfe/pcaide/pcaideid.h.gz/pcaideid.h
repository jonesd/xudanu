//REGEN_FILEHEADING
//REGEN_FILEHEADING

     /********************************************************************
      *                                                                  *
      *   Source File: PCAideID.h                                        *
      *   Description: Header file IDS for PCAide application            *
      *   Date:        Fri May 07 10:31:25 1993                          *
      *                                                                  *
      ********************************************************************/

#ifndef __PCAIDEID__H
#define __PCAIDEID__H

#include <time.h>

//REGEN_HEADER
//REGEN_HEADER

// Defines for menu item IDs
#define   IDM_ATTENTION                       101
#define   IDM_AKORD                           102
#define   IDM_RATE                            103
#define   IDM_MEMO                            104
#define   IDM_UM                              105
#define   IDM_CPROFILE                        106
#define   IDM_PAPERS                          107
#define   IDM_INITIALIZE                      108
#define   IDM_RETURNHOME                      109
#define   IDM_WRITETODISK                     110
#define   IDM_NEXTDEMO                        111


#endif // __PCAIDEID__H
