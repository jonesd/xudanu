//FILEHEADING_BEGIN
//FILEHEADING_END

     /********************************************************************
      *
      *   Source File: AKORD.h                                           *
      *   Description: AKORD CGL Form                                    *
      *   Author:      Ravi Pandya                                       *
      *   Date:        Mon Mar 08 13:38:39 1993                          *
      *
      ********************************************************************/


//HEADERFILE_BEGIN
//HEADERFILE_END
// Field number defines


HANDLE   hInst;                           // Global application instance handle
VIEW     AKORD;                           // Main view handle
HWND     hWndAKORD;


HWND fn(HWND);
