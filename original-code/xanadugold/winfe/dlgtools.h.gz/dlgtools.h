#ifndef DLGTOOLS
#define DLGTOOLS
         
class TStatic;
class TEdit;
#include "absui.h"
#include <windows.h>

class DialogTools {
public:
	// Set the text of the control when it is fulfilled
	static void setEditText (XuEditionP edition, TStatic* control);
	static void setEditText (XuSequenceP sequence, TStatic* control);

	// set the selection of the control when it is fulfilled
	static void setSelection (XuIntValueP start, XuIntValueP stop, TEdit* edit);

	// align the window according to some abstract guidelines
	static void align (HWND, FEUI::Alignment horizontal, FEUI::Alignment vertical);
};

#endif DLGTOOLS
